-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 11 月 28 日 09:26
-- 服务器版本: 5.5.40
-- PHP 版本: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dws`
--

-- --------------------------------------------------------

--
-- 表的结构 `wemall_qinghuo_cat`
--

CREATE TABLE IF NOT EXISTS `wemall_qinghuo_cat` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `wemall_qinghuo_cat`
--

INSERT INTO `wemall_qinghuo_cat` (`id`, `title`) VALUES
(2, '生活百货'),
(5, '成人用品');

-- --------------------------------------------------------

--
-- 表的结构 `wemall_qinghuo_good`
--

CREATE TABLE IF NOT EXISTS `wemall_qinghuo_good` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `catid` int(50) NOT NULL,
  `uid` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `headimg` varchar(250) NOT NULL,
  `codeimg` varchar(250) NOT NULL,
  `goodimg` varchar(250) NOT NULL,
  `miaoshu` text NOT NULL,
  `yuanjia` varchar(50) NOT NULL,
  `xianjia` varchar(50) NOT NULL,
  `uptime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `zdtime` varchar(200) NOT NULL,
  `startime` varchar(250) DEFAULT '0',
  `gmtime` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=37 ;

--
-- 转存表中的数据 `wemall_qinghuo_good`
--

INSERT INTO `wemall_qinghuo_good` (`id`, `catid`, `uid`, `title`, `headimg`, `codeimg`, `goodimg`, `miaoshu`, `yuanjia`, `xianjia`, `uptime`, `zdtime`, `startime`, `gmtime`) VALUES
(36, 5, 'oNUNGs-oivmpZ38CEcz5Sovnq57Q', '黑色麦旋风咖啡????', '', '1448440179a.jpg', '1448445991a.jpg', '关注麦当劳！！！。。。。', '55女', '29', '2015-11-26 02:59:36', '0', '0', '1448503336');

-- --------------------------------------------------------

--
-- 表的结构 `wemall_qinghuo_zdtime`
--

CREATE TABLE IF NOT EXISTS `wemall_qinghuo_zdtime` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `jiage` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `wemall_qinghuo_zdtime`
--

INSERT INTO `wemall_qinghuo_zdtime` (`id`, `title`, `jiage`, `time`) VALUES
(1, '清货置顶10分钟', '0.01', '600'),
(2, '清货置顶1小时', '0.02', '3600'),
(3, '清货置顶500秒', '0.01', '500');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
